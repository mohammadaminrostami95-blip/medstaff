const sequelize = require('../config/db');
const User = require('./User');
const OtpCode = require('./OtpCode');
const StaffProfile = require('./StaffProfile');
const FacilityProfile = require('./FacilityProfile');
const JobPost = require('./JobPost');

// Associations
User.hasOne(StaffProfile, { foreignKey: 'userId', as: 'staffProfile' });
StaffProfile.belongsTo(User, { foreignKey: 'userId' });

User.hasOne(FacilityProfile, { foreignKey: 'userId', as: 'facilityProfile' });
FacilityProfile.belongsTo(User, { foreignKey: 'userId' });

FacilityProfile.hasMany(JobPost, { foreignKey: 'facilityId', as: 'jobPosts' });
JobPost.belongsTo(FacilityProfile, { foreignKey: 'facilityId', as: 'facility' });

// متخصص پیدا شده برای آگهی
JobPost.belongsTo(StaffProfile, { foreignKey: 'filledStaffId', as: 'filledBy' });

module.exports = { sequelize, User, OtpCode, StaffProfile, FacilityProfile, JobPost };
