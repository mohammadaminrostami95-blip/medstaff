const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const JobPost = sequelize.define('JobPost', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  facilityId: { type: DataTypes.UUID, allowNull: false, references: { model: 'facility_profiles', key: 'id' } },
  title: { type: DataTypes.STRING(200), allowNull: false }, // عنوان آگهی
  staffType: {
    type: DataTypes.ENUM('physician', 'nurse', 'midwife', 'technician', 'pharmacist', 'other'),
    allowNull: false,
  },
  specialty: { type: DataTypes.STRING(100) },
  requiredCount: { type: DataTypes.INTEGER, defaultValue: 1 }, // تعداد مورد نیاز
  salaryMin: { type: DataTypes.BIGINT }, // حداقل حقوق (ریال)
  salaryMax: { type: DataTypes.BIGINT }, // حداکثر حقوق
  salaryDescription: { type: DataTypes.STRING(300) }, // توضیح حقوق
  employmentType: {
    type: DataTypes.ENUM('full_time', 'part_time', 'contract', 'shift'),
    defaultValue: 'full_time',
  },
  requirements: { type: DataTypes.TEXT }, // شرایط احراز
  description: { type: DataTypes.TEXT }, // توضیحات
  deadline: { type: DataTypes.DATE }, // مهلت ارسال رزومه
  isActive: { type: DataTypes.BOOLEAN, defaultValue: true },
  // متخصص این حوزه پیدا شده است
  isFilled: { type: DataTypes.BOOLEAN, defaultValue: false },
  filledAt: { type: DataTypes.DATE },
  filledStaffId: { type: DataTypes.UUID, allowNull: true, references: { model: 'staff_profiles', key: 'id' } },
}, { tableName: 'job_posts', timestamps: true });

module.exports = JobPost;
