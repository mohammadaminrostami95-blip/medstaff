const router = require('express').Router();
const { body, validationResult } = require('express-validator');
const { sendOtp, verifyOtp } = require('../controllers/authController');
const validate = (req, res, next) => {
  const errors = validationResult(req);
  return errors.isEmpty() ? next() : res.status(400).json({ message: 'اطلاعات واردشده معتبر نیست.' });
};
router.post('/send-otp', body('phone').matches(/^09[0-9]{9}$/), validate, sendOtp);
router.post('/verify-otp', body('phone').matches(/^09[0-9]{9}$/), body('code').isLength({ min: 6, max: 6 }).isNumeric(), validate, verifyOtp);
module.exports = router;
