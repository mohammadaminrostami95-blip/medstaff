const router = require('express').Router();
const { body } = require('express-validator');
const validate = require('../middleware/validate');
const { sendCode, verifyCode } = require('../controllers/authController');

const phone = body('phone').isString().matches(/^09[0-9]{9}$/).withMessage('شماره موبایل معتبر نیست.');
router.post('/send-code', phone, validate, sendCode);
router.post('/verify', phone,
  body('code').isString().matches(/^[0-9]{6}$/).withMessage('کد باید ۶ رقم باشد.'),
  body('role').optional().isIn(['staff', 'facility']),
  validate, verifyCode);
module.exports = router;
