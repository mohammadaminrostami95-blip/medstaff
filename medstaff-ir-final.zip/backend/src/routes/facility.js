const router = require('express').Router();
const { authenticate, requireRole } = require('../middleware/auth');
const ctrl = require('../controllers/facilityController');

router.get('/jobs/search', ctrl.searchJobs); // عمومی
router.get('/me', authenticate, requireRole('facility'), ctrl.getMyProfile);
router.put('/me', authenticate, requireRole('facility'), ctrl.upsertProfile);
router.post('/jobs', authenticate, requireRole('facility'), ctrl.createJobPost);
router.put('/jobs/:id', authenticate, requireRole('facility'), ctrl.updateJobPost);

module.exports = router;
