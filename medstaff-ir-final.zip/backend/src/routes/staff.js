const router = require('express').Router();
const { authenticate, requireRole } = require('../middleware/auth');
const ctrl = require('../controllers/staffController');

router.get('/search', ctrl.searchStaff); // عمومی
router.get('/me', authenticate, requireRole('staff'), ctrl.getMyProfile);
router.put('/me', authenticate, requireRole('staff'), ctrl.upsertProfile);

module.exports = router;
