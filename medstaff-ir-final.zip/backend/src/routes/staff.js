const router = require('express').Router();
const { authenticate, requireRole } = require('../middleware/auth');
const ctrl = require('../controllers/staffController');
router.get('/', ctrl.searchStaff);
router.get('/search', ctrl.searchStaff);
router.get('/me', authenticate, requireRole('staff'), ctrl.getMyProfile);
router.put('/me', authenticate, requireRole('staff'), ctrl.upsertProfile);
module.exports = router;
