const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const StaffProfile = sequelize.define('StaffProfile', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  userId: { type: DataTypes.UUID, allowNull: false, references: { model: 'users', key: 'id' } },
  fullName: { type: DataTypes.STRING(100), allowNull: false },
  // نوع کادر: physician, nurse, midwife, technician, other
  staffType: {
    type: DataTypes.ENUM('physician', 'nurse', 'midwife', 'technician', 'pharmacist', 'other'),
    allowNull: false,
  },
  specialty: { type: DataTypes.STRING(100) }, // تخصص
  subspecialty: { type: DataTypes.STRING(100) }, // فوق‌تخصص
  medicalCouncilNumber: { type: DataTypes.STRING(20), unique: true }, // شماره نظام پزشکی
  university: { type: DataTypes.STRING(150) }, // دانشگاه محل تحصیل
  graduationYear: { type: DataTypes.INTEGER },
  degree: {
    type: DataTypes.ENUM('MD', 'GP', 'specialist', 'subspecialist', 'nurse_bsc', 'nurse_msc', 'MPH', 'PhD', 'other'),
    allowNull: false,
  },
  hasMPH: { type: DataTypes.BOOLEAN, defaultValue: false },
  additionalDegrees: { type: DataTypes.TEXT }, // مدارک تکمیلی
  bio: { type: DataTypes.TEXT },
  city: { type: DataTypes.STRING(80) }, // شهر فعلی
  province: { type: DataTypes.STRING(80) }, // استان
  preferredProvinces: { type: DataTypes.ARRAY(DataTypes.STRING) }, // استان‌های مورد نظر برای کار
  isAvailable: { type: DataTypes.BOOLEAN, defaultValue: true }, // آماده به کار
  phone: { type: DataTypes.STRING(11) }, // تلفن تماس عمومی (اختیاری)
  email: { type: DataTypes.STRING(150) },
}, { tableName: 'staff_profiles', timestamps: true });

module.exports = StaffProfile;
