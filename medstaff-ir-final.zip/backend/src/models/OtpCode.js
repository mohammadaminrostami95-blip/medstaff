const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');
module.exports = sequelize.define('OtpCode', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  phone: { type: DataTypes.STRING(11), allowNull: false },
  code: { type: DataTypes.STRING(6), allowNull: false },
  expiresAt: { type: DataTypes.DATE, allowNull: false },
  used: { type: DataTypes.BOOLEAN, defaultValue: false },
}, { tableName: 'otp_codes', timestamps: true, indexes: [{ fields: ['phone', 'createdAt'] }] });
