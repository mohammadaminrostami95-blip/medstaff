const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const OtpCode = sequelize.define('OtpCode', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  phone: { type: DataTypes.STRING(11), allowNull: false },
  code: { type: DataTypes.STRING(64), allowNull: false }, // SHA-256 hash
  attempts: { type: DataTypes.INTEGER, defaultValue: 0 },
  expiresAt: { type: DataTypes.DATE, allowNull: false },
  used: { type: DataTypes.BOOLEAN, defaultValue: false },
}, { tableName: 'otp_codes', timestamps: true });

module.exports = OtpCode;
