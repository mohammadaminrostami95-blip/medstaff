const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const FacilityProfile = sequelize.define('FacilityProfile', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  userId: { type: DataTypes.UUID, allowNull: false, references: { model: 'users', key: 'id' } },
  name: { type: DataTypes.STRING(150), allowNull: false }, // نام مرکز
  facilityType: {
    type: DataTypes.ENUM('hospital', 'clinic', 'polyclinic', 'health_center', 'lab', 'imaging', 'other'),
    allowNull: false,
  },
  licenseNumber: { type: DataTypes.STRING(30) }, // شماره مجوز
  address: { type: DataTypes.TEXT, allowNull: false },
  city: { type: DataTypes.STRING(80), allowNull: false },
  province: { type: DataTypes.STRING(80), allowNull: false },
  phone: { type: DataTypes.STRING(20), allowNull: false },
  website: { type: DataTypes.STRING(200) },
  description: { type: DataTypes.TEXT },
  isVerified: { type: DataTypes.BOOLEAN, defaultValue: false },
}, { tableName: 'facility_profiles', timestamps: true });

module.exports = FacilityProfile;
