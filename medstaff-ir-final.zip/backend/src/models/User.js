const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const User = sequelize.define('User', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  phone: {
    type: DataTypes.STRING(11),
    allowNull: false,
    unique: true,
    validate: { is: /^09[0-9]{9}$/ }, // Iranian mobile format
  },
  role: {
    type: DataTypes.ENUM('staff', 'facility', 'admin'),
    allowNull: false,
    defaultValue: 'staff',
  },
  isVerified: { type: DataTypes.BOOLEAN, defaultValue: false },
  isActive: { type: DataTypes.BOOLEAN, defaultValue: true },
}, { tableName: 'users', timestamps: true });

module.exports = User;
