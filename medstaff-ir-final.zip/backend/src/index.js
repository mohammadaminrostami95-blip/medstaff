require('dotenv').config();
const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const { sequelize } = require('./models');
const app = express();
app.use(cors({ origin: process.env.FRONTEND_URL || true, credentials: true }));
app.use(express.json({ limit: '1mb' }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 100, message: 'تعداد درخواست زیاد است.' }));
app.use('/api/auth', require('./routes/auth'));
app.use('/api/staff', require('./routes/staff'));
app.use('/api/facility', require('./routes/facility'));
app.get('/api/health', (_, res) => res.json({ status: 'ok' }));
const port = Number(process.env.PORT) || 5000;
sequelize.authenticate().then(() => sequelize.sync({ alter: process.env.NODE_ENV === 'development' }))
  .then(() => app.listen(port, () => console.log(`Server running on port ${port}`)))
  .catch(error => { console.error('Database connection failed:', error); process.exit(1); });
