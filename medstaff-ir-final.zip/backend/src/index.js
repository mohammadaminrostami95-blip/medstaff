require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 16) {
  console.error('JWT_SECRET must be set (min 16 chars).');
  process.exit(1);
}
const { sequelize } = require('./models');

const app = express();
app.set('trust proxy', 1);
app.use(helmet());
app.use(cors({ origin: (process.env.FRONTEND_URL || 'http://localhost:5173').split(','), credentials: true }));
app.use(express.json({ limit: '100kb' }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 300, standardHeaders: true, legacyHeaders: false, message: { message: 'تعداد درخواست زیاد است.' } }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, max: 30, message: { message: 'تعداد تلاش زیاد است. بعداً دوباره امتحان کنید.' } }));

app.use('/api/auth', require('./routes/auth'));
app.use('/api/staff', require('./routes/staff'));
app.use('/api/facility', require('./routes/facility'));
app.get('/api/health', (_, res) => res.json({ status: 'ok' }));

app.use('/api', (req, res) => res.status(404).json({ message: 'مسیر یافت نشد.' }));
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') return res.status(400).json({ message: 'JSON نامعتبر است.' });
  console.error(err);
  res.status(500).json({ message: 'خطای سرور.' });
});

const PORT = process.env.PORT || 5000;
sequelize.sync({ alter: process.env.NODE_ENV === 'development' })
  .then(() => app.listen(PORT, () => console.log(`Server running on port ${PORT}`)))
  .catch((e) => { console.error(e); process.exit(1); });
module.exports = app;
