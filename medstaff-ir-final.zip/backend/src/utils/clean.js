function cleanObject(obj) {
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return {};
  return Object.fromEntries(Object.entries(obj).flatMap(([key, value]) => {
    if (value === undefined || value === null) return [];
    if (typeof value === 'string') { const trimmed = value.trim(); return trimmed ? [[key, trimmed]] : []; }
    return [[key, value]];
  }));
}
module.exports = cleanObject;
module.exports.cleanObject = cleanObject;
