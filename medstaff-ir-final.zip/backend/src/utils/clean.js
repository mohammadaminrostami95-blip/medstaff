function cleanObject(obj) {
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return {};
  return Object.fromEntries(Object.entries(obj).flatMap(([key, value]) => {
    if (value === undefined || value === null) return [];
    if (typeof value === 'string') { const t = value.trim(); return t ? [[key, t]] : []; }
    return [[key, value]];
  }));
}
// فقط فیلدهای مجاز؛ رشته خالی => null
function pick(obj, fields) {
  const out = {};
  if (!obj || typeof obj !== 'object') return out;
  for (const f of fields) {
    if (!(f in obj)) continue;
    let v = obj[f];
    if (typeof v === 'string') { v = v.trim(); if (v === '') v = null; }
    out[f] = v;
  }
  return out;
}
module.exports = cleanObject;
module.exports.cleanObject = cleanObject;
module.exports.pick = pick;
