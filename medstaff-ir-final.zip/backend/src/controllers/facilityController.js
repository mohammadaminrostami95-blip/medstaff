const { FacilityProfile, JobPost } = require('../models');
const { Op } = require('sequelize');
const { pick } = require('../utils/clean');

const FACILITY_FIELDS = ['name', 'facilityType', 'licenseNumber', 'address', 'city', 'province', 'phone', 'website', 'description'];
const JOB_FIELDS = ['title', 'staffType', 'specialty', 'requiredCount', 'salaryMin', 'salaryMax', 'salaryDescription',
  'employmentType', 'requirements', 'description', 'deadline', 'isActive'];

const bad = (err) => ['SequelizeValidationError', 'SequelizeUniqueConstraintError', 'SequelizeDatabaseError'].includes(err.name);
const num = (data, k) => { if (data[k] !== undefined && data[k] !== null) data[k] = Number(data[k]); };
const esc = (s) => String(s).replace(/[\\%_]/g, '\\$&');

const upsertProfile = async (req, res, next) => {
  try {
    const data = pick(req.body, FACILITY_FIELDS);
    let profile = await FacilityProfile.findOne({ where: { userId: req.user.id } });
    if (profile) { await profile.update(data); return res.json(profile); }
    profile = await FacilityProfile.create({ ...data, userId: req.user.id });
    res.status(201).json(profile);
  } catch (err) {
    if (bad(err)) return res.status(400).json({ message: 'اطلاعات واردشده نامعتبر است.' });
    next(err);
  }
};

const getMyProfile = async (req, res, next) => {
  try {
    const profile = await FacilityProfile.findOne({
      where: { userId: req.user.id },
      include: [{ association: 'jobPosts', where: { isActive: true }, required: false }],
    });
    if (!profile) return res.status(404).json({ message: 'پروفایل یافت نشد.' });
    res.json(profile);
  } catch (err) { next(err); }
};

const createJobPost = async (req, res, next) => {
  try {
    const facility = await FacilityProfile.findOne({ where: { userId: req.user.id } });
    if (!facility) return res.status(400).json({ message: 'ابتدا پروفایل مرکز را تکمیل کنید.' });
    const data = pick(req.body, JOB_FIELDS);
    ['requiredCount', 'salaryMin', 'salaryMax'].forEach((k) => num(data, k));
    const post = await JobPost.create({ ...data, facilityId: facility.id });
    res.status(201).json(post);
  } catch (err) {
    if (bad(err)) return res.status(400).json({ message: 'اطلاعات آگهی نامعتبر است.' });
    next(err);
  }
};

const updateJobPost = async (req, res, next) => {
  try {
    const facility = await FacilityProfile.findOne({ where: { userId: req.user.id } });
    if (!facility) return res.status(400).json({ message: 'ابتدا پروفایل مرکز را تکمیل کنید.' });
    const post = await JobPost.findOne({ where: { id: req.params.id, facilityId: facility.id } });
    if (!post) return res.status(404).json({ message: 'آگهی یافت نشد.' });
    const data = pick(req.body, JOB_FIELDS);
    ['requiredCount', 'salaryMin', 'salaryMax'].forEach((k) => num(data, k));
    await post.update(data);
    res.json(post);
  } catch (err) {
    if (bad(err)) return res.status(400).json({ message: 'اطلاعات آگهی نامعتبر است.' });
    next(err);
  }
};

const searchJobs = async (req, res, next) => {
  try {
    const { specialty, staffType, province, city } = req.query;
    const limit = Math.min(Math.max(parseInt(req.query.limit) || 20, 1), 50);
    const page = Math.max(parseInt(req.query.page) || 1, 1);
    const facilityWhere = {};
    if (province) facilityWhere.province = { [Op.iLike]: `%${esc(province)}%` };
    if (city) facilityWhere.city = { [Op.iLike]: `%${esc(city)}%` };
    const jobWhere = { isActive: true };
    if (specialty) jobWhere.specialty = { [Op.iLike]: `%${esc(specialty)}%` };
    if (staffType) jobWhere.staffType = String(staffType);
    const { rows, count } = await JobPost.findAndCountAll({
      where: jobWhere,
      include: [{ association: 'facility', where: facilityWhere, required: true, attributes: { exclude: ['userId', 'licenseNumber'] } }],
      limit, offset: (page - 1) * limit, order: [['createdAt', 'DESC']],
    });
    res.json({ total: count, page, data: rows });
  } catch (err) {
    if (err.name === 'SequelizeDatabaseError') return res.status(400).json({ message: 'پارامتر جستجو نامعتبر است.' });
    next(err);
  }
};

module.exports = { upsertProfile, getMyProfile, createJobPost, updateJobPost, searchJobs };
