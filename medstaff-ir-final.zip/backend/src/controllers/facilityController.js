const { FacilityProfile, JobPost } = require('../models');
const { Op } = require('sequelize');

const upsertProfile = async (req, res) => {
  try {
    const userId = req.user.id;
    const [profile] = await FacilityProfile.upsert({ ...req.body, userId }, { returning: true });
    res.json(profile);
  } catch (err) {
    res.status(500).json({ message: 'خطا در ذخیره پروفایل مرکز.' });
  }
};

const getMyProfile = async (req, res) => {
  const profile = await FacilityProfile.findOne({
    where: { userId: req.user.id },
    include: [{ association: 'jobPosts', where: { isActive: true }, required: false }],
  });
  if (!profile) return res.status(404).json({ message: 'پروفایل یافت نشد.' });
  res.json(profile);
};

// ایجاد آگهی نیاز به نیرو
const createJobPost = async (req, res) => {
  try {
    const facility = await FacilityProfile.findOne({ where: { userId: req.user.id } });
    if (!facility) return res.status(400).json({ message: 'ابتدا پروفایل مرکز را تکمیل کنید.' });

    const post = await JobPost.create({ ...req.body, facilityId: facility.id });
    res.status(201).json(post);
  } catch (err) {
    res.status(500).json({ message: 'خطا در ایجاد آگهی.' });
  }
};

const updateJobPost = async (req, res) => {
  try {
    const facility = await FacilityProfile.findOne({ where: { userId: req.user.id } });
    const post = await JobPost.findOne({ where: { id: req.params.id, facilityId: facility.id } });
    if (!post) return res.status(404).json({ message: 'آگهی یافت نشد.' });
    await post.update(req.body);
    res.json(post);
  } catch (err) {
    res.status(500).json({ message: 'خطای سرور.' });
  }
};

// جستجوی آگهی‌های شغلی
const searchJobs = async (req, res) => {
  try {
    const { specialty, staffType, province, city, page = 1, limit = 20 } = req.query;

    const facilityWhere = {};
    if (province) facilityWhere.province = { [Op.iLike]: `%${province}%` };
    if (city) facilityWhere.city = { [Op.iLike]: `%${city}%` };

    const jobWhere = { isActive: true };
    if (specialty) jobWhere.specialty = { [Op.iLike]: `%${specialty}%` };
    if (staffType) jobWhere.staffType = staffType;

    const { rows, count } = await JobPost.findAndCountAll({
      where: jobWhere,
      include: [{ association: 'facility', where: facilityWhere, required: true }],
      limit: Math.min(Number(limit), 50),
      offset: (Number(page) - 1) * Number(limit),
      order: [['createdAt', 'DESC']],
    });

    res.json({ total: count, page: Number(page), data: rows });
  } catch (err) {
    res.status(500).json({ message: 'خطا در جستجو.' });
  }
};

module.exports = { upsertProfile, getMyProfile, createJobPost, updateJobPost, searchJobs };
