const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const { Op } = require('sequelize');
const { User, OtpCode } = require('../models');
const { sendOtp } = require('../services/sms');

const MAX_ATTEMPTS = 5;
const hashCode = (phone, code) =>
  crypto.createHmac('sha256', process.env.JWT_SECRET).update(`${phone}:${code}`).digest('hex');
const expireMinutes = () => Number(process.env.OTP_EXPIRE_MINUTES) || 5;

const sendCode = async (req, res, next) => {
  try {
    const { phone } = req.body;
    const recent = await OtpCode.count({
      where: { phone, createdAt: { [Op.gte]: new Date(Date.now() - 10 * 60 * 1000) } },
    });
    if (recent >= 3) {
      return res.status(429).json({ message: 'تعداد درخواست زیاد است. لطفاً ۱۰ دقیقه صبر کنید.' });
    }
    const code = String(crypto.randomInt(100000, 1000000));
    await OtpCode.create({
      phone, code: hashCode(phone, code),
      expiresAt: new Date(Date.now() + expireMinutes() * 60 * 1000),
    });

    // فقط در حالت توسعه و بدون کلید کاوه‌نگار، کد در پاسخ برگردانده می‌شود
    if ((process.env.NODE_ENV === 'development' || process.env.OTP_DEBUG === 'true') && !process.env.KAVENEGAR_API_KEY) {
      return res.json({ message: 'کد ارسال شد (حالت توسعه).', devCode: code });
    }
    try {
      await sendOtp(phone, code);
    } catch (e) {
      console.error('SMS error:', e.message);
      return res.status(502).json({ message: 'ارسال پیامک ناموفق بود. دوباره تلاش کنید.' });
    }
    res.json({ message: 'کد تأیید به شماره شما ارسال شد.' });
  } catch (err) { next(err); }
};

const verifyCode = async (req, res, next) => {
  try {
    const { phone, code, role } = req.body;
    const otp = await OtpCode.findOne({
      where: { phone, used: false, expiresAt: { [Op.gt]: new Date() } },
      order: [['createdAt', 'DESC']],
    });
    if (!otp || otp.attempts >= MAX_ATTEMPTS) {
      return res.status(400).json({ message: 'کد منقضی شده یا نامعتبر است. کد جدید بگیرید.' });
    }
    const a = Buffer.from(hashCode(phone, code));
    const b = Buffer.from(otp.code);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
      await otp.increment('attempts');
      return res.status(400).json({ message: 'کد اشتباه است.' });
    }
    // مصرف اتمیک کد
    const [n] = await OtpCode.update({ used: true }, { where: { id: otp.id, used: false } });
    if (!n) return res.status(400).json({ message: 'کد قبلاً استفاده شده است.' });

    let user = await User.findOne({ where: { phone } });
    const isNew = !user;
    if (!user) {
      user = await User.create({ phone, role: role === 'facility' ? 'facility' : 'staff', isVerified: true });
    } else if (!user.isActive) {
      return res.status(403).json({ message: 'حساب کاربری غیرفعال است.' });
    }
    const token = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });
    res.json({ token, user: { id: user.id, phone: user.phone, role: user.role }, isNew });
  } catch (err) { next(err); }
};

module.exports = { sendCode, verifyCode };
