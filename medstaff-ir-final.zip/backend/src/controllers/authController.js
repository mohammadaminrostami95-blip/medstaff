const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const { Op } = require('sequelize');
const { User, OtpCode } = require('../models');
const { sendOtp } = require('../services/sms');

async function sendOtp(req, res) {
  try {
    const { phone } = req.body;
    if (!/^09[0-9]{9}$/.test(phone || '')) return res.status(400).json({ message: 'شماره موبایل معتبر نیست.' });
    const recentCount = await OtpCode.count({ where: { phone, createdAt: { [Op.gte]: new Date(Date.now() - 600000) } } });
    if (recentCount >= 3) return res.status(429).json({ message: 'تعداد درخواست زیاد است. لطفاً ۱۰ دقیقه صبر کنید.' });
    const code = String(crypto.randomInt(100000, 1000000));
    const minutes = Math.max(1, Number(process.env.OTP_EXPIRE_MINUTES) || 5);
    await OtpCode.create({ phone, code, expiresAt: new Date(Date.now() + minutes * 60000) });
    if (process.env.NODE_ENV === 'development') return res.json({ message: 'کد تأیید آماده است.', devCode: code });
    await sendOtp(phone, code);
    return res.json({ message: 'کد تأیید به شماره شما ارسال شد.' });
  } catch (err) { console.error(err); return res.status(500).json({ message: 'خطای سرور در ارسال کد.' }); }
}
async function verifyOtp(req, res) {
  try {
    const { phone, code, role } = req.body;
    if (!/^09[0-9]{9}$/.test(phone || '') || !/^\d{6}$/.test(code || '')) return res.status(400).json({ message: 'شماره موبایل یا کد تأیید معتبر نیست.' });
    const otp = await OtpCode.findOne({ where: { phone, code, used: false }, order: [['createdAt', 'DESC']] });
    if (!otp || Date.now() > new Date(otp.expiresAt).getTime()) return res.status(400).json({ message: 'کد اشتباه یا منقضی شده است.' });
    await otp.update({ used: true });
    let user = await User.findOne({ where: { phone } });
    const isNew = !user;
    if (!user) user = await User.create({ phone, role: ['staff', 'facility'].includes(role) ? role : 'staff', isVerified: true });
    const token = jwt.sign({ id: user.id, phone: user.phone, role: user.role }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });
    return res.json({ token, user: { id: user.id, phone: user.phone, role: user.role }, isNew });
  } catch (err) { console.error(err); return res.status(500).json({ message: 'خطای سرور در تأیید کد.' }); }
}
module.exports = { sendOtp, verifyOtp };
