const { StaffProfile } = require('../models');
const { Op } = require('sequelize');
const clean = require('../utils/clean');
const fields = ['fullName','staffType','specialty','subspecialty','medicalCouncilNumber','university','graduationYear','degree','hasMPH','additionalDegrees','bio','city','province','preferredProvinces','isAvailable','phone','email'];
async function upsertProfile(req, res) {
  try {
    const data = Object.fromEntries(Object.entries(clean(req.body)).filter(([k]) => fields.includes(k)));
    if (!data.fullName || !data.staffType || !data.degree) return res.status(400).json({ message: 'نام، نوع کادر و مدرک تحصیلی الزامی است.' });
    const existing = await StaffProfile.findOne({ where: { userId: req.user.id } });
    const profile = existing ? await existing.update(data) : await StaffProfile.create({ ...data, userId: req.user.id });
    return res.status(existing ? 200 : 201).json(profile);
  } catch (err) { console.error(err); return res.status(400).json({ message: 'خطا در ذخیره پروفایل؛ اطلاعات واردشده را بررسی کنید.' }); }
}
async function getMyProfile(req, res) {
  try { const profile = await StaffProfile.findOne({ where: { userId: req.user.id } }); return profile ? res.json(profile) : res.status(404).json({ message: 'پروفایل یافت نشد.' }); }
  catch (err) { return res.status(500).json({ message: 'خطای سرور.' }); }
}
async function searchStaff(req, res) {
  try {
    const { specialty, staffType, province, city } = req.query;
    const page = Math.max(1, parseInt(req.query.page, 10) || 1), limit = Math.min(50, Math.max(1, parseInt(req.query.limit, 10) || 20));
    const where = { isAvailable: true };
    for (const [key, value] of Object.entries({ specialty, province, city })) if (value) where[key] = { [Op.iLike]: `%${String(value).slice(0,80)}%` };
    if (staffType) where.staffType = staffType;
    const { rows, count } = await StaffProfile.findAndCountAll({ where, attributes: { exclude: ['userId','phone','email','medicalCouncilNumber'] }, limit, offset: (page-1)*limit, order: [['createdAt','DESC']] });
    return res.json({ total: count, page, data: rows });
  } catch (err) { console.error(err); return res.status(500).json({ message: 'خطا در جستجوی کادر درمان.' }); }
}
module.exports = { upsertProfile, getMyProfile, searchStaff };
