const { StaffProfile } = require('../models');
const { Op } = require('sequelize');
const { pick } = require('../utils/clean');

const FIELDS = ['fullName', 'staffType', 'specialty', 'subspecialty', 'medicalCouncilNumber', 'university',
  'graduationYear', 'degree', 'hasMPH', 'additionalDegrees', 'bio', 'city', 'province',
  'preferredProvinces', 'isAvailable', 'phone', 'email'];

const errMsg = (err) => (err.name === 'SequelizeValidationError' || err.name === 'SequelizeUniqueConstraintError' || err.name === 'SequelizeDatabaseError')
  ? 'اطلاعات واردشده نامعتبر یا تکراری است.' : null;

const upsertProfile = async (req, res, next) => {
  try {
    const data = pick(req.body, FIELDS);
    let profile = await StaffProfile.findOne({ where: { userId: req.user.id } });
    if (profile) { await profile.update(data); return res.json(profile); }
    profile = await StaffProfile.create({ ...data, userId: req.user.id });
    res.status(201).json(profile);
  } catch (err) {
    const m = errMsg(err);
    if (m) return res.status(400).json({ message: m });
    next(err);
  }
};

const getMyProfile = async (req, res, next) => {
  try {
    const profile = await StaffProfile.findOne({ where: { userId: req.user.id } });
    if (!profile) return res.status(404).json({ message: 'پروفایل یافت نشد.' });
    res.json(profile);
  } catch (err) { next(err); }
};

const esc = (s) => String(s).replace(/[\\%_]/g, '\\$&');

const searchStaff = async (req, res, next) => {
  try {
    const { specialty, staffType, province, city, isAvailable } = req.query;
    const limit = Math.min(Math.max(parseInt(req.query.limit) || 20, 1), 50);
    const page = Math.max(parseInt(req.query.page) || 1, 1);
    const where = {};
    if (specialty) where.specialty = { [Op.iLike]: `%${esc(specialty)}%` };
    if (staffType) where.staffType = String(staffType);
    if (province) where.province = { [Op.iLike]: `%${esc(province)}%` };
    if (city) where.city = { [Op.iLike]: `%${esc(city)}%` };
    if (isAvailable !== undefined) where.isAvailable = isAvailable === 'true';
    const { rows, count } = await StaffProfile.findAndCountAll({
      where, limit, offset: (page - 1) * limit, order: [['createdAt', 'DESC']],
      attributes: { exclude: ['userId', 'medicalCouncilNumber'] },
    });
    res.json({ total: count, page, data: rows });
  } catch (err) {
    if (err.name === 'SequelizeDatabaseError') return res.status(400).json({ message: 'پارامتر جستجو نامعتبر است.' });
    next(err);
  }
};

module.exports = { upsertProfile, getMyProfile, searchStaff };
