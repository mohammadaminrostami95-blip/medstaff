const { Sequelize } = require('sequelize');
const options = {
  dialect: 'postgres',
  logging: process.env.NODE_ENV === 'development' ? console.log : false,
  pool: { max: 10, min: 0, acquire: 30000, idle: 10000 },
};
const sequelize = process.env.DATABASE_URL
  ? new Sequelize(process.env.DATABASE_URL, { ...options, dialectOptions: process.env.DATABASE_SSL === 'true' ? { ssl: { require: true, rejectUnauthorized: false } } : {} })
  : new Sequelize(process.env.DB_NAME || 'medstaff', process.env.DB_USER || 'medstaff', process.env.DB_PASS || 'medstaff', { ...options, host: process.env.DB_HOST || 'localhost', port: Number(process.env.DB_PORT) || 5432 });
module.exports = sequelize;
