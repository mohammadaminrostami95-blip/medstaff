const { KavenegarApi } = require('kavenegar');

const sendOtp = (phone, code) => new Promise((resolve, reject) => {
  if (!process.env.KAVENEGAR_API_KEY) return reject(new Error('KAVENEGAR_API_KEY is not set'));
  const api = KavenegarApi({ apikey: process.env.KAVENEGAR_API_KEY });
  api.VerifyLookup(
    { receptor: phone, token: code, template: process.env.KAVENEGAR_TEMPLATE || 'medstaff-otp' },
    (response, status) => (status === 200 ? resolve(response) : reject(new Error(`SMS failed with status ${status}`)))
  );
});
module.exports = { sendOtp };
