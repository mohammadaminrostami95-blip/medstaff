const KavenegarApi = require('kavenegar').KavenegarApi;
async function sendOtp(phone, code) {
  if (!process.env.KAVENEGAR_API_KEY) throw new Error('KAVENEGAR_API_KEY تنظیم نشده است.');
  const api = KavenegarApi({ apikey: process.env.KAVENEGAR_API_KEY });
  return new Promise((resolve, reject) => api.VerifyLookup({ receptor: phone, token: code, template: process.env.KAVENEGAR_OTP_TEMPLATE || 'medstaff-otp' }, (response, status) => {
    if (Number(status) === 200) resolve(response);
    else reject(new Error(`ارسال پیامک ناموفق بود (کد ${status}).`));
  }));
}
module.exports = { sendOtp };
