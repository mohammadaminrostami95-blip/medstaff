import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Navbar from './components/Navbar';
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import StaffProfilePage from './pages/StaffProfilePage';
import FacilityProfilePage from './pages/FacilityProfilePage';
import JobsPage from './pages/JobsPage';
import StaffSearchPage from './pages/StaffSearchPage';

function ProtectedRoute({ children, role }) {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (!user) return <Navigate to="/login" replace />;
  if (role && user.role !== role) return <Navigate to="/" replace />;
  return children;
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Navbar />
        <main style={{ paddingTop: '5rem' }}>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/jobs" element={<JobsPage />} />
            <Route path="/staff" element={<StaffSearchPage />} />
            <Route
              path="/profile/staff"
              element={<ProtectedRoute role="staff"><StaffProfilePage /></ProtectedRoute>}
            />
            <Route
              path="/profile/facility"
              element={<ProtectedRoute role="facility"><FacilityProfilePage /></ProtectedRoute>}
            />
          </Routes>
        </main>
      </BrowserRouter>
    </AuthProvider>
  );
}
