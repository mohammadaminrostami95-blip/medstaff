import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../api/axios';

const STEPS = { PHONE: 'phone', CODE: 'code', ROLE: 'role' };

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(STEPS.PHONE);
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [role, setRole] = useState('staff');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [countdown, setCountdown] = useState(0);

  const startCountdown = () => {
    setCountdown(120);
    const t = setInterval(() => {
      setCountdown((c) => { if (c <= 1) { clearInterval(t); return 0; } return c - 1; });
    }, 1000);
  };

  const handleSendCode = async (e) => {
    e.preventDefault();
    setError('');
    if (!/^09[0-9]{9}$/.test(phone)) { setError('شماره موبایل معتبر وارد کنید (مثال: 09123456789)'); return; }
    setLoading(true);
    try {
      await api.post('/auth/send-code', { phone });
      setStep(STEPS.CODE);
      startCountdown();
    } catch (err) {
      setError(err.response?.data?.message || 'خطا در ارسال کد.');
    } finally { setLoading(false); }
  };

  const handleVerify = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const { data } = await api.post('/auth/verify', { phone, code, role });
      login(data.token, data.user);
      if (data.isNew) {
        navigate(data.user.role === 'facility' ? '/profile/facility' : '/profile/staff');
      } else {
        navigate('/');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'کد اشتباه است.');
    } finally { setLoading(false); }
  };

  return (
    <div style={{ minHeight: 'calc(100vh - 5rem)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem' }}>
      <div className="card" style={{ width: '100%', maxWidth: '420px' }}>
        <h1 style={{ fontSize: '1.4rem', fontWeight: 700, marginBottom: '0.5rem' }}>ورود / ثبت‌نام</h1>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginBottom: '1.75rem' }}>
          با شماره موبایل ایرانی وارد شوید.
        </p>

        {step === STEPS.PHONE && (
          <form onSubmit={handleSendCode}>
            <div className="form-group">
              <label className="form-label" htmlFor="phone">شماره موبایل</label>
              <input
                id="phone" type="tel" className="form-input"
                placeholder="09123456789" value={phone} dir="ltr"
                onChange={(e) => setPhone(e.target.value)} maxLength={11}
              />
            </div>
            <div className="form-group">
              <label className="form-label">نوع حساب</label>
              <select className="form-input" value={role} onChange={(e) => setRole(e.target.value)}>
                <option value="staff">کادر درمان (پزشک، پرستار و ...)</option>
                <option value="facility">مرکز درمانی (بیمارستان، کلینیک و ...)</option>
              </select>
            </div>
            {error && <p className="form-error" style={{ marginBottom: '0.75rem' }}>{error}</p>}
            <button className="btn btn-primary" type="submit" disabled={loading} style={{ width: '100%' }}>
              {loading ? 'در حال ارسال...' : 'ارسال کد تأیید'}
            </button>
          </form>
        )}

        {step === STEPS.CODE && (
          <form onSubmit={handleVerify}>
            <p style={{ marginBottom: '1rem', fontSize: '0.9rem' }}>
              کد ۶ رقمی به <strong dir="ltr">{phone}</strong> ارسال شد.
            </p>
            <div className="form-group">
              <label className="form-label" htmlFor="code">کد تأیید</label>
              <input
                id="code" type="text" className="form-input"
                placeholder="------" value={code} dir="ltr"
                onChange={(e) => setCode(e.target.value)} maxLength={6}
                style={{ letterSpacing: '0.3em', fontSize: '1.3rem', textAlign: 'center' }}
              />
            </div>
            {error && <p className="form-error" style={{ marginBottom: '0.75rem' }}>{error}</p>}
            <button className="btn btn-primary" type="submit" disabled={loading} style={{ width: '100%' }}>
              {loading ? 'در حال تأیید...' : 'تأیید و ورود'}
            </button>
            <div style={{ marginTop: '1rem', textAlign: 'center', fontSize: '0.85rem', color: 'var(--text-muted)' }}>
              {countdown > 0
                ? `ارسال مجدد تا ${countdown} ثانیه دیگر`
                : <button type="button" style={{ background: 'none', border: 'none', color: 'var(--accent-600)', cursor: 'pointer' }} onClick={handleSendCode}>ارسال مجدد کد</button>
              }
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
