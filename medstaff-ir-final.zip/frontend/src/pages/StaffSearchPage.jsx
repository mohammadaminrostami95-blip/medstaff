import React, { useEffect, useState } from 'react';

const labels = { physician: 'پزشک', nurse: 'پرستار', midwife: 'ماما', technician: 'کارشناس / تکنسین', pharmacist: 'داروساز', other: 'سایر' };
export default function StaffSearchPage() {
  const [filters, setFilters] = useState({ specialty: '', city: '', staffType: '', available: true });
  const [staff, setStaff] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  useEffect(() => {
    const controller = new AbortController();
    const params = new URLSearchParams();
    for (const key of ['specialty', 'city', 'staffType']) if (filters[key]) params.set(key, filters[key]);
    params.set('available', String(filters.available));
    setLoading(true); setError('');
    fetch(`/api/staff/search?${params}`, { signal: controller.signal })
      .then(async response => { if (!response.ok) throw new Error('دریافت نتایج با خطا روبه‌رو شد.'); return response.json(); })
      .then(result => setStaff(Array.isArray(result) ? result : (result.data || [])))
      .catch(err => { if (err.name !== 'AbortError') { setError(err.message); setStaff([]); } })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, [filters]);
  const change = (key, value) => setFilters(current => ({ ...current, [key]: value }));
  return <section dir="rtl" className="mx-auto min-h-screen max-w-7xl px-5 py-10 text-slate-800">
    <header className="mb-8"><h1 className="text-3xl font-bold">جستجوی کادر درمان</h1><p className="mt-2 text-slate-600">متخصص موردنظر خود را بر اساس شهر و حوزه فعالیت پیدا کنید.</p></header>
    <div className="grid gap-7 lg:grid-cols-[280px_1fr]">
      <aside className="h-fit rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><h2 className="mb-5 text-lg font-bold">فیلترها</h2>
        <label className="mb-2 block text-sm font-medium" htmlFor="type">گروه شغلی</label><select id="type" value={filters.staffType} onChange={e=>change('staffType',e.target.value)} className="mb-5 w-full rounded-lg border border-slate-300 bg-white p-3"><option value="">همه گروه‌ها</option>{Object.entries(labels).map(([v,l])=><option key={v} value={v}>{l}</option>)}</select>
        <label className="mb-2 block text-sm font-medium" htmlFor="specialty">تخصص</label><input id="specialty" value={filters.specialty} onChange={e=>change('specialty',e.target.value)} placeholder="مثلاً قلب و عروق" className="mb-5 w-full rounded-lg border border-slate-300 p-3" />
        <label className="mb-2 block text-sm font-medium" htmlFor="city">شهر</label><input id="city" value={filters.city} onChange={e=>change('city',e.target.value)} placeholder="نام شهر" className="mb-5 w-full rounded-lg border border-slate-300 p-3" />
        <label className="flex cursor-pointer items-center gap-3"><input type="checkbox" checked={filters.available} onChange={e=>change('available',e.target.checked)} className="h-4 w-4 accent-teal-700" />فقط افراد آماده به کار</label>
      </aside>
      <div>{loading ? <p className="rounded-xl bg-white p-8 text-center">در حال دریافت نتایج…</p> : error ? <p role="alert" className="rounded-xl bg-red-50 p-5 text-red-700">{error}</p> : staff.length === 0 ? <p className="rounded-xl bg-white p-8 text-center text-slate-600">نتیجه‌ای برای جستجوی شما یافت نشد.</p> : <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{staff.map(person=><article key={person.id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div className="flex items-start justify-between gap-3"><div><h2 className="text-lg font-bold">{person.fullName || 'کادر درمان'}</h2><p className="mt-1 text-sm text-teal-800">{labels[person.staffType] || person.staffType || 'کادر درمان'}</p></div><span className={`shrink-0 rounded-full px-3 py-1 text-xs ${person.isAvailable ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'}`}>{person.isAvailable ? 'آماده به کار' : 'در دسترس نیست'}</span></div><p className="mt-4 text-sm text-slate-600">تخصص: {person.specialty || 'ثبت نشده'}</p><p className="mt-2 text-sm text-slate-600">شهر: {person.city || 'ثبت نشده'}</p></article>)}</div>}</div>
    </div>
  </section>;
}
