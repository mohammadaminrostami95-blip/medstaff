import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

export default function HomePage() {
  const [specialty, setSpecialty] = useState('');
  const [city, setCity] = useState('');
  const navigate = useNavigate();
  function search(event) {
    event.preventDefault();
    const params = new URLSearchParams();
    if (specialty.trim()) params.set('specialty', specialty.trim());
    if (city.trim()) params.set('city', city.trim());
    navigate(`/search${params.size ? `?${params}` : ''}`);
  }
  return <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-800">
    <section className="bg-gradient-to-l from-teal-800 to-cyan-700 px-5 py-24 text-white">
      <div className="mx-auto max-w-6xl">
        <span className="rounded-full bg-white/15 px-4 py-2 text-sm">همراه مطمئن مسیر حرفه‌ای شما</span>
        <h1 className="mt-8 text-4xl font-bold leading-tight md:text-6xl">سامانه استخدام پزشکی ایران</h1>
        <p className="mt-5 max-w-2xl text-lg leading-8 text-teal-50">فرصت‌های شغلی مراکز درمانی و متخصصان حوزه سلامت را در یکجا پیدا کنید و ارتباط حرفه‌ای خود را گسترش دهید.</p>
        <form onSubmit={search} className="mt-10 grid gap-3 rounded-2xl bg-white p-4 shadow-xl md:grid-cols-[1fr_1fr_auto]">
          <label className="sr-only" htmlFor="home-specialty">تخصص</label><input id="home-specialty" value={specialty} onChange={e=>setSpecialty(e.target.value)} placeholder="تخصص یا گروه شغلی" className="rounded-xl border border-slate-200 px-4 py-3 text-slate-800 outline-none focus:border-teal-600" />
          <label className="sr-only" htmlFor="home-city">شهر</label><input id="home-city" value={city} onChange={e=>setCity(e.target.value)} placeholder="شهر" className="rounded-xl border border-slate-200 px-4 py-3 text-slate-800 outline-none focus:border-teal-600" />
          <button className="rounded-xl bg-teal-700 px-7 py-3 font-semibold text-white hover:bg-teal-800">جستجو</button>
        </form>
        <Link to="/search" className="mt-5 inline-block rounded-xl border border-white/70 px-6 py-3 text-white hover:bg-white/10">مشاهده کادر درمان</Link>
      </div>
    </section>
    <section className="mx-auto grid max-w-6xl gap-5 px-5 py-14 md:grid-cols-3">
      {[['جستجوی هدفمند','بر اساس تخصص، شهر و وضعیت آمادگی به کار جستجو کنید.'],['فرصت‌های تازه','با مراکز درمانی و فرصت‌های شغلی مرتبط آشنا شوید.'],['پروفایل حرفه‌ای','مهارت‌ها و سوابق خود را در دسترس مراکز قرار دهید.']].map(([title,desc])=><article key={title} className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"><h2 className="text-xl font-bold text-teal-800">{title}</h2><p className="mt-3 leading-7 text-slate-600">{desc}</p></article>)}
    </section>
  </div>;
}
