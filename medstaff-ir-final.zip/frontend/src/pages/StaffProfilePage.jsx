import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import api from '../api/axios';

const SPECIALTIES = [
  'قلب و عروق', 'مغز و اعصاب', 'ارتوپدی', 'زنان و زایمان', 'اطفال',
  'جراحی عمومی', 'داخلی', 'پوست', 'چشم', 'گوش حلق بینی', 'روانپزشکی',
  'رادیولوژی', 'آنستزیولوژی', 'اورژانس', 'دندانپزشکی', 'فیزیوتراپی', 'سایر',
];
const PROVINCES = [
  'تهران', 'اصفهان', 'فارس', 'خراسان رضوی', 'مازندران', 'آذربایجان شرقی',
  'آذربایجان غربی', 'کرمانشاه', 'گیلان', 'سیستان و بلوچستان', 'کرمان',
  'خوزستان', 'همدان', 'لرستان', 'بوشهر', 'گلستان', 'زنجان', 'مرکزی',
  'سمنان', 'یزد', 'قم', 'قزوین', 'ایلام', 'چهارمحال و بختیاری',
  'کهگیلویه و بویراحمد', 'خراسان شمالی', 'خراسان جنوبی', 'اردبیل',
  'البرز', 'هرمزگان',
];

export default function StaffProfilePage() {
  const { register, handleSubmit, reset, formState: { errors } } = useForm();
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api.get('/staff/me').then(({ data }) => reset(data)).catch(() => {});
  }, [reset]);

  const onSubmit = async (data) => {
    setLoading(true);
    try {
      await api.put('/staff/me', data);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err) {
      alert(err.response?.data?.message || 'خطا در ذخیره.');
    } finally { setLoading(false); }
  };

  return (
    <div className="container" style={{ paddingTop: '2rem', paddingBottom: '4rem', maxWidth: '680px' }}>
      <h1 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: '0.4rem' }}>پروفایل حرفه‌ای</h1>
      <p style={{ color: 'var(--text-muted)', marginBottom: '2rem' }}>اطلاعات شما برای مراکز درمانی نمایش داده می‌شود.</p>

      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="card" style={{ marginBottom: '1.5rem' }}>
          <h2 style={{ fontSize: '1.05rem', fontWeight: 600, marginBottom: '1.25rem' }}>اطلاعات شخصی</h2>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 1rem' }}>
            <div className="form-group">
              <label className="form-label">نام و نام خانوادگی *</label>
              <input className="form-input" {...register('fullName', { required: 'الزامی' })} />
              {errors.fullName && <span className="form-error">{errors.fullName.message}</span>}
            </div>
            <div className="form-group">
              <label className="form-label">تلفن تماس عمومی</label>
              <input className="form-input" dir="ltr" {...register('phone')} placeholder="09..." />
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">ایمیل</label>
            <input className="form-input" type="email" dir="ltr" {...register('email')} />
          </div>
        </div>

        <div className="card" style={{ marginBottom: '1.5rem' }}>
          <h2 style={{ fontSize: '1.05rem', fontWeight: 600, marginBottom: '1.25rem' }}>اطلاعات حرفه‌ای</h2>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 1rem' }}>
            <div className="form-group">
              <label className="form-label">نوع کادر *</label>
              <select className="form-input" {...register('staffType', { required: 'الزامی' })}>
                <option value="">انتخاب کنید</option>
        Continuing from where the output was cut off — here are the remaining files:
                <option value="physician">پزشک</option>
                <option value="nurse">پرستار</option>
                <option value="midwife">ماما</option>
                <option value="technician">تکنسین</option>
                <option value="pharmacist">داروساز</option>
                <option value="other">سایر</option>
              </select>
              {errors.staffType && <span className="form-error">{errors.staffType.message}</span>}
            </div>
            <div className="form-group">
              <label className="form-label">مدرک تحصیلی *</label>
              <select className="form-input" {...register('degree', { required: 'الزامی' })}>
                <option value="">انتخاب کنید</option>
                <option value="MD">دکتری عمومی (MD)</option>
                <option value="GP">پزشک عمومی</option>
                <option value="specialist">متخصص</option>
                <option value="subspecialist">فوق‌تخصص</option>
                <option value="nurse_bsc">کارشناسی پرستاری</option>
                <option value="nurse_msc">کارشناسی ارشد پرستاری</option>
                <option value="MPH">MPH</option>
                <option value="PhD">PhD</option>
                <option value="other">سایر</option>
              </select>
              {errors.degree && <span className="form-error">{errors.degree.message}</span>}
            </div>
            <div className="form-group">
              <label className="form-label">تخصص</label>
              <select className="form-input" {...register('specialty')}>
                <option value="">انتخاب کنید</option>
                {SPECIALTIES.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">فوق‌تخصص</label>
              <input className="form-input" {...register('subspecialty')} />
            </div>
            <div className="form-group">
              <label className="form-label">شماره نظام پزشکی</label>
              <input className="form-input" dir="ltr" {...register('medicalCouncilNumber')} />
            </div>
            <div className="form-group">
              <label className="form-label">دانشگاه</label>
              <input className="form-input" {...register('university')} />
            </div>
            <div className="form-group">
              <label className="form-label">سال فارغ‌التحصیلی</label>
              <input className="form-input" type="number" dir="ltr" {...register('graduationYear', { valueAsNumber: true })} />
            </div>
          </div>
          <div className="form-group">
            <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <input type="checkbox" {...register('hasMPH')} /> دارای مدرک MPH
            </label>
          </div>
          <div className="form-group">
            <label className="form-label">مدارک تکمیلی</label>
            <textarea className="form-input" rows={2} {...register('additionalDegrees')} style={{ resize: 'vertical' }} />
          </div>
          <div className="form-group">
            <label className="form-label">درباره من</label>
            <textarea className="form-input" rows={3} {...register('bio')} style={{ resize: 'vertical' }} />
          </div>
        </div>

        <div className="card" style={{ marginBottom: '1.5rem' }}>
          <h2 style={{ fontSize: '1.05rem', fontWeight: 600, marginBottom: '1.25rem' }}>محل و ترجیحات کاری</h2>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 1rem' }}>
            <div className="form-group">
              <label className="form-label">استان</label>
              <select className="form-input" {...register('province')}>
                <option value="">انتخاب کنید</option>
                {PROVINCES.map((p) => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">شهر</label>
              <input className="form-input" {...register('city')} />
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">استان‌های مورد نظر برای کار</label>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem 1rem' }}>
              {PROVINCES.map((p) => (
                <label key={p} style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', fontSize: '0.85rem' }}>
                  <input type="checkbox" value={p} {...register('preferredProvinces')} /> {p}
                </label>
              ))}
            </div>
          </div>
          <div className="form-group">
            <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <input type="checkbox" {...register('isAvailable')} /> آماده به کار هستم
            </label>
          </div>
        </div>

        <button className="btn btn-primary" type="submit" disabled={loading} style={{ width: '100%', padding: '0.75rem' }}>
          {loading ? 'در حال ذخیره...' : saved ? '✓ ذخیره شد' : 'ذخیره پروفایل'}
        </button>
      </form>
    </div>
  );
}
