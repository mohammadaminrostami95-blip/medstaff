import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import api from '../api/axios';

const SPECIALTIES = [
  'قلب و عروق', 'مغز و اعصاب', 'ارتوپدی', 'زنان و زایمان', 'اطفال',
  'جراحی عمومی', 'داخلی', 'پوست', 'چشم', 'گوش حلق بینی', 'روانپزشکی',
  'رادیولوژی', 'آنستزیولوژی', 'اورژانس', 'دندانپزشکی', 'فیزیوتراپی', 'سایر',
];
const PROVINCES = [
  'تهران', 'اصفهان', 'فارس', 'خراسان رضوی', 'مازندران', 'آذربایجان شرقی',
  'آذربایجان غربی', 'کرمانشاه', 'گیلان', 'سیستان و بلوچستان', 'کرمان',
  'خوزستان', 'همدان', 'لرستان', 'بوشهر', 'گلستان', 'زنجان', 'مرکزی',
  'سمنان', 'یزد', 'قم', 'قزوین', 'ایلام', 'چهارمحال و بختیاری',
  'کهگیلویه و بویراحمد', 'خراسان شمالی', 'خراسان جنوبی', 'اردبیل',
  'البرز', 'هرمزگان',
];

export default function StaffProfilePage() {
  const { register, handleSubmit, reset, formState: { errors } } = useForm();
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api.get('/staff/me').then(({ data }) => reset(data)).catch(() => {});
  }, [reset]);

  const onSubmit = async (data) => {
    setLoading(true);
    try {
      await api.put('/staff/me', data);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err) {
      alert(err.response?.data?.message || 'خطا در ذخیره.');
    } finally { setLoading(false); }
  };

  return (
    <div className="container" style={{ paddingTop: '2rem', paddingBottom: '4rem', maxWidth: '680px' }}>
      <h1 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: '0.4rem' }}>پروفایل حرفه‌ای</h1>
      <p style={{ color: 'var(--text-muted)', marginBottom: '2rem' }}>اطلاعات شما برای مراکز درمانی نمایش داده می‌شود.</p>

      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="card" style={{ marginBottom: '1.5rem' }}>
          <h2 style={{ fontSize: '1.05rem', fontWeight: 600, marginBottom: '1.25rem' }}>اطلاعات شخصی</h2>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 1rem' }}>
            <div className="form-group">
              <label className="form-label">نام و نام خانوادگی *</label>
              <input className="form-input" {...register('fullName', { required: 'الزامی' })} />
              {errors.fullName && <span className="form-error">{errors.fullName.message}</span>}
            </div>
            <div className="form-group">
              <label className="form-label">تلفن تماس عمومی</label>
              <input className="form-input" dir="ltr" {...register('phone')} placeholder="09..." />
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">ایمیل</label>
            <input className="form-input" type="email" dir="ltr" {...register('email')} />
          </div>
        </div>

        <div className="card" style={{ marginBottom: '1.5rem' }}>
          <h2 style={{ fontSize: '1.05rem', fontWeight: 600, marginBottom: '1.25rem' }}>اطلاعات حرفه‌ای</h2>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 1rem' }}>
            <div className="form-group">
              <label className="form-label">نوع کادر *</label>
              <select className="form-input" {...register('staffType', { required: 'الزامی' })}>
                <option value="">انتخاب کنید</option>
        Continuing from where the output was cut off — here are the remaining files:

### `frontend/src/pages/StaffProfilePage.jsx` (continued from select options)

