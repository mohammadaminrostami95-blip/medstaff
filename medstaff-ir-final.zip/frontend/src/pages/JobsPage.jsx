import React, { useState, useEffect, useCallback } from 'react';
import api from '../api/axios';

const PROVINCES = [
  'همه', 'تهران', 'اصفهان', 'فارس', 'خراسان رضوی', 'مازندران', 'آذربایجان شرقی',
  'کرمانشاه', 'گیلان', 'سیستان و بلوچستان', 'کرمان', 'خوزستان', 'همدان',
  'هرمزگان', 'البرز', 'اردبیل',
];
const STAFF_TYPES = { physician: 'پزشک', nurse: 'پرستار', midwife: 'ماما', pharmacist: 'داروساز', technician: 'تکنسین', other: 'سایر' };
const EMPLOYMENT_TYPES = { full_time: 'تمام‌وقت', part_time: 'پاره‌وقت', contract: 'قراردادی', shift: 'شیفتی' };

function JobCard({ job }) {
  const facility = job.facility || {};
  return (
    <div className="card" style={{ marginBottom: '1rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '1rem' }}>
        <div style={{ flex: 1 }}>
          <h3 style={{ fontSize: '1rem', fontWeight: 600, marginBottom: '0.35rem' }}>{job.title}</h3>
          <p style={{ fontSize: '0.88rem', color: 'var(--text-muted)', marginBottom: '0.6rem' }}>
            🏥 {facility.name} — {facility.city}، {facility.province}
          </p>
          <div style={{ display: 'flex', gap: '0.4rem', flexWrap: 'wrap' }}>
            {job.specialty && <span className="badge badge-teal">{job.specialty}</span>}
            <span className="badge badge-gray">{STAFF_TYPES[job.staffType] || job.staffType}</span>
            <span className="badge badge-gray">{EMPLOYMENT_TYPES[job.employmentType] || job.employmentType}</span>
            {job.requiredCount > 1 && <span className="badge badge-gray">{job.requiredCount} نفر</span>}
          </div>
        </div>
        <div style={{ textAlign: 'left', flexShrink: 0 }}>
          {job.salaryMin ? (
            <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
              از {Number(job.salaryMin).toLocaleString('fa-IR')} ریال
            </div>
          ) : job.salaryDescription ? (
            <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', maxWidth: '120px', textAlign: 'right' }}>
              {job.salaryDescription}
            </div>
          ) : null}
        </div>
      </div>
      {job.requirements && (
        <p style={{ marginTop: '0.75rem', fontSize: '0.85rem', color: 'var(--text-muted)', borderTop: '1px solid var(--border)', paddingTop: '0.65rem' }}>
          {job.requirements}
        </p>
      )}
      {facility.phone && (
        <div style={{ marginTop: '0.6rem', fontSize: '0.85rem' }}>
          📞 <a href={`tel:${facility.phone}`} dir="ltr">{facility.phone}</a>
        </div>
      )}
    </div>
  );
}

export default function JobsPage() {
  const [jobs, setJobs] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState({ specialty: '', staffType: '', province: '', city: '' });

  const load = useCallback(async (p = 1, f = filters) => {
    setLoading(true);
    try {
      const params = { page: p, limit: 20, ...Object.fromEntries(Object.entries(f).filter(([, v]) => v && v !== 'همه')) };
      const { data } = await api.get('/facility/jobs/search', { params });
      setJobs(data.data);
      setTotal(data.total);
      setPage(p);
    } catch {
      /* ignore */
    } finally { setLoading(false); }
  }, [filters]);

  useEffect(() => { load(1, filters); }, []); // initial load

  const handleFilter = (e) => {
    e.preventDefault();
    load(1, filters);
  };

  return (
    <div className="container" style={{ paddingTop: '2rem', paddingBottom: '4rem' }}>
      <h1 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: '0.25rem' }}>آگهی‌های شغلی</h1>
      <p style={{ color: 'var(--text-muted)', marginBottom: '1.75rem' }}>فرصت‌های شغلی برای کادر درمان در سراسر کشور</p>

      {/* فیلترها */}
      <form onSubmit={handleFilter} style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap', marginBottom: '1.75rem' }}>
        <input className="form-input" style={{ flex: '1 1 160px' }} placeholder="تخصص..." value={filters.specialty}
          onChange={e => setFilters(f => ({ ...f, specialty: e.target.value }))} />
        <select className="form-input" style={{ flex: '1 1 140px' }} value={filters.staffType}
          onChange={e => setFilters(f => ({ ...f, staffType: e.target.value }))}>
          <option value="">همه کادر</option>
          <option value="physician">پزشک</option>
          <option value="nurse">پرستار</option>
          <option value="midwife">ماما</option>
          <option value="pharmacist">داروساز</option>
          <option value="technician">تکنسین</option>
        </select>
        <select className="form-input" style={{ flex: '1 1 140px' }} value={filters.province}
          onChange={e => setFilters(f => ({ ...f, province: e.target.value === 'همه' ? '' : e.target.value }))}>
          {PROVINCES.map(p => <option key={p} value={p}>{p}</option>)}
        </select>
        <input className="form-input" style={{ flex: '1 1 120px' }} placeholder="شهر..." value={filters.city}
          onChange={e => setFilters(f => ({ ...f, city: e.target.value }))} />
        <button className="btn btn-primary" type="submit" style={{ flexShrink: 0 }}>جستجو</button>
      </form>

      {loading ? (
        <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>در حال بارگذاری...</div>
      ) : jobs.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>آگهی‌ای یافت نشد.</div>
      ) : (
        <>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '1rem' }}>
            {total.toLocaleString('fa-IR')} آگهی یافت شد
          </p>
          {jobs.map(job => <JobCard key={job.id} job={job} />)}
          {total > 20 && (
            <div style={{ display: 'flex', justifyContent: 'center', gap: '0.5rem', marginTop: '1.5rem' }}>
              {page > 1 && <button className="btn btn-outline" onClick={() => load(page - 1)}>قبلی</button>}
              <span style={{ padding: '0.6rem 1rem', fontSize: '0.9rem', color: 'var(--text-muted)' }}>صفحه {page}</span>
              {page * 20 < total && <button className="btn btn-outline" onClick={() => load(page + 1)}>بعدی</button>}
            </div>
          )}
        </>
      )}
    </div>
  );
}
