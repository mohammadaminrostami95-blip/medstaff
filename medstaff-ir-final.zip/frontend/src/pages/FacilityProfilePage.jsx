import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import api from '../api/axios';

const PROVINCES = [
  'تهران', 'اصفهان', 'فارس', 'خراسان رضوی', 'مازندران', 'آذربایجان شرقی',
  'آذربایجان غربی', 'کرمانشاه', 'گیلان', 'سیستان و بلوچستان', 'کرمان',
  'خوزستان', 'همدان', 'لرستان', 'بوشهر', 'گلستان', 'زنجان', 'مرکزی',
  'سمنان', 'یزد', 'قم', 'قزوین', 'ایلام', 'چهارمحال و بختیاری',
  'کهگیلویه و بویراحمد', 'خراسان شمالی', 'خراسان جنوبی', 'اردبیل',
  'البرز', 'هرمزگان',
];
const SPECIALTIES = [
  'قلب و عروق', 'مغز و اعصاب', 'ارتوپدی', 'زنان و زایمان', 'اطفال',
  'جراحی عمومی', 'داخلی', 'پوست', 'چشم', 'گوش حلق بینی', 'روانپزشکی',
  'رادیولوژی', 'آنستزیولوژی', 'اورژانس', 'دندانپزشکی', 'فیزیوتراپی', 'سایر',
];

function JobPostForm({ facilityId, onSaved }) {
  const { register, handleSubmit, reset, formState: { errors } } = useForm();
  const [loading, setLoading] = useState(false);

  const onSubmit = async (data) => {
    setLoading(true);
    try {
      await api.post('/facility/jobs', data);
      reset();
      onSaved();
    } catch (err) {
      alert(err.response?.data?.message || 'خطا در ثبت آگهی.');
    } finally { setLoading(false); }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="form-group">
        <label className="form-label">عنوان آگهی *</label>
        <input className="form-input" {...register('title', { required: 'الزامی' })} placeholder="مثال: نیاز به متخصص قلب تمام‌وقت" />
        {errors.title && <span className="form-error">{errors.title.message}</span>}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 1rem' }}>
        <div className="form-group">
          <label className="form-label">نوع کادر مورد نیاز *</label>
          <select className="form-input" {...register('staffType', { required: 'الزامی' })}>
            <option value="">انتخاب کنید</option>
            <option value="physician">پزشک</option>
            <option value="nurse">پرستار</option>
            <option value="midwife">ماما</option>
            <option value="pharmacist">داروساز</option>
            <option value="technician">تکنسین / پاراکلینیک</option>
            <option value="other">سایر</option>
          </select>
        </div>
        <div className="form-group">
          <label className="form-label">تخصص مورد نیاز</label>
          <select className="form-input" {...register('specialty')}>
            <option value="">همه</option>
            {SPECIALTIES.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '0 1rem' }}>
        <div className="form-group">
          <label className="form-label">تعداد مورد نیاز</label>
          <input className="form-input" type="number" min={1} defaultValue={1} dir="ltr" {...register('requiredCount')} />
        </div>
        <div className="form-group">
          <label className="form-label">نوع همکاری</label>
          <select className="form-input" {...register('employmentType')}>
            <option value="full_time">تمام‌وقت</option>
            <option value="part_time">پاره‌وقت</option>
            <option value="contract">قراردادی</option>
            <option value="shift">شیفتی</option>
          </select>
        </div>
        <div className="form-group">
          <label className="form-label">مهلت ارسال رزومه</label>
          <input className="form-input" type="date" dir="ltr" {...register('deadline')} />
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 1rem' }}>
        <div className="form-group">
          <label className="form-label">حداقل حقوق (ریال)</label>
          <input className="form-input" type="number" dir="ltr" {...register('salaryMin')} placeholder="اختیاری" />
        </div>
        <div className="form-group">
          <label className="form-label">حداکثر حقوق (ریال)</label>
          <input className="form-input" type="number" dir="ltr" {...register('salaryMax')} placeholder="اختیاری" />
        </div>
      </div>

      <div className="form-group">
        <label className="form-label">توضیح حقوق و مزایا</label>
        <input className="form-input" {...register('salaryDescription')} placeholder="مثال: بیمه تکمیلی، بن غذا، پاداش عملکرد..." />
      </div>

      <div className="form-group">
        <label className="form-label">شرایط احراز</label>
        <textarea className="form-input" rows={3} {...register('requirements')} style={{ resize: 'vertical' }}
          placeholder="مثال: حداقل ۵ سال سابقه، عضو هیئت علمی..." />
      </div>

      <div className="form-group">
        <label className="form-label">توضیحات بیشتر</label>
        <textarea className="form-input" rows={3} {...register('description')} style={{ resize: 'vertical' }} />
      </div>

      <button className="btn btn-primary" type="submit" disabled={loading}>
        {loading ? 'در حال ثبت...' : 'ثبت آگهی'}
      </button>
    </form>
  );
}

export default function FacilityProfilePage() {
  const { register, handleSubmit, reset, formState: { errors } } = useForm();
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(false);
  const [jobPosts, setJobPosts] = useState([]);
  const [showJobForm, setShowJobForm] = useState(false);

  const loadProfile = () => {
    api.get('/facility/me')
      .then(({ data }) => {
        reset(data);
        setJobPosts(data.jobPosts || []);
      })
      .catch(() => {});
  };

  useEffect(() => { loadProfile(); }, []);

  const onSubmit = async (data) => {
    setLoading(true);
    try {
      await api.put('/facility/me', data);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err) {
      alert(err.response?.data?.message || 'خطا در ذخیره.');
    } finally { setLoading(false); }
  };

  return (
    <div className="container" style={{ paddingTop: '2rem', paddingBottom: '4rem', maxWidth: '720px' }}>
      <h1 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: '0.4rem' }}>پروفایل مرکز درمانی</h1>
      <p style={{ color: 'var(--text-muted)', marginBottom: '2rem' }}>اطلاعات مرکز شما در جستجوی کادر درمان نمایش داده می‌شود.</p>

      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="card" style={{ marginBottom: '1.5rem' }}>
          <h2 style={{ fontSize: '1.05rem', fontWeight: 600, marginBottom: '1.25rem' }}>اطلاعات مرکز</h2>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 1rem' }}>
            <div className="form-group">
              <label className="form-label">نام مرکز *</label>
              <input className="form-input" {...register('name', { required: 'الزامی' })} />
              {errors.name && <span className="form-error">{errors.name.message}</span>}
            </div>
            <div className="form-group">
              <label className="form-label">نوع مرکز *</label>
              <select className="form-input" {...register('facilityType', { required: 'الزامی' })}>
                <option value="">انتخاب کنید</option>
                <option value="hospital">بیمارستان</option>
                <option value="clinic">کلینیک</option>
                <option value="polyclinic">پلی‌کلینیک</option>
                <option value="health_center">مرکز بهداشت</option>
                <option value="lab">آزمایشگاه</option>
                <option value="imaging">مرکز تصویربرداری</option>
                <option value="other">سایر</option>
              </select>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 1rem' }}>
            <div className="form-group">
              <label className="form-label">شماره مجوز</label>
              <input className="form-input" dir="ltr" {...register('licenseNumber')} />
            </div>
            <div className="form-group">
              <label className="form-label">تلفن تماس *</label>
              <input className="form-input" dir="ltr" {...register('phone', { required: 'الزامی' })} placeholder="021..." />
              {errors.phone && <span className="form-error">{errors.phone.message}</span>}
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">وب‌سایت</label>
            <input className="form-input" dir="ltr" type="url" {...register('website')} placeholder="https://..." />
          </div>
        </div>

        <div className="card" style={{ marginBottom: '1.5rem' }}>
          <h2 style={{ fontSize: '1.05rem', fontWeight: 600, marginBottom: '1.25rem' }}>آدرس</h2>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 1rem' }}>
            <div className="form-group">
              <label className="form-label">استان *</label>
              <select className="form-input" {...register('province', { required: 'الزامی' })}>
                <option value="">انتخاب کنید</option>
                {PROVINCES.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">شهر *</label>
              <input className="form-input" {...register('city', { required: 'الزامی' })} />
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">آدرس کامل *</label>
            <textarea className="form-input" rows={2} {...register('address', { required: 'الزامی' })} style={{ resize: 'vertical' }} />
          </div>
          <div className="form-group">
            <label className="form-label">درباره مرکز</label>
            <textarea className="form-input" rows={3} {...register('description')} style={{ resize: 'vertical' }}
              placeholder="معرفی کوتاه مرکز، تخصص‌ها و خدمات..." />
          </div>
        </div>

        {saved && (
          <div style={{
            padding: '0.75rem 1rem', borderRadius: 'var(--radius-sm)',
            background: 'oklch(92% 0.08 145)', color: 'oklch(32% 0.10 145)',
            marginBottom: '1rem', fontSize: '0.9rem',
          }}>
            پروفایل با موفقیت ذخیره شد.
          </div>
        )}
        <button className="btn btn-primary" type="submit" disabled={loading} style={{ width: '100%', padding: '0.75rem', marginBottom: '2rem' }}>
          {loading ? 'در حال ذخیره...' : 'ذخیره پروفایل'}
        </button>
      </form>

      {/* آگهی‌های شغلی */}
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
          <h2 style={{ fontSize: '1.05rem', fontWeight: 600 }}>آگهی‌های شغلی ({jobPosts.length})</h2>
          <button className="btn btn-outline" style={{ padding: '0.4rem 1rem', fontSize: '0.85rem' }}
            onClick={() => setShowJobForm(v => !v)}>
            {showJobForm ? 'بستن فرم' : '+ آگهی جدید'}
          </button>
        </div>

        {showJobForm && (
          <div style={{ borderTop: '1px solid var(--border)', paddingTop: '1.5rem', marginBottom: '1.5rem' }}>
            <JobPostForm onSaved={() => { setShowJobForm(false); loadProfile(); }} />
          </div>
        )}

        {jobPosts.length === 0 ? (
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>هنوز آگهی شغلی ثبت نشده.</p>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            {jobPosts.map(post => (
              <div key={post.id} style={{
                padding: '1rem', borderRadius: 'var(--radius-md)',
                border: '1px solid var(--border)', background: 'var(--surface)',
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <strong style={{ fontSize: '0.95rem' }}>{post.title}</strong>
                    <div style={{ display: 'flex', gap: '0.5rem', marginTop: '0.4rem', flexWrap: 'wrap' }}>
                      {post.specialty && <span className="badge badge-teal">{post.specialty}</span>}
                      <span className="badge badge-gray">تعداد: {post.requiredCount}</span>
                      {post.salaryMin && (
                        <span className="badge badge-gray">
                          از {Number(post.salaryMin).toLocaleString('fa-IR')} ریال
                        </span>
                      )}
                    </div>
                  </div>
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>
                    {post.isActive ? '✓ فعال' : '✗ غیرفعال'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
