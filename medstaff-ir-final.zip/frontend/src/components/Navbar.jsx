import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => { logout(); navigate('/'); };

  return (
    <nav style={{
      position: 'fixed', top: 0, right: 0, left: 0, zIndex: 100,
      background: 'var(--surface-raised)',
      borderBottom: '1px solid var(--border)',
      height: '4rem',
      display: 'flex', alignItems: 'center',
    }}>
      <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
        <Link to="/" style={{ fontWeight: 700, fontSize: '1.2rem', color: 'var(--accent-600)', textDecoration: 'none' }}>
          🏥 مدستاف
        </Link>
        <div style={{ display: 'flex', gap: '1.25rem', alignItems: 'center' }}>
          <Link to="/jobs" style={{ color: 'var(--text)', fontSize: '0.9rem' }}>آگهی‌های شغلی</Link>
          <Link to="/staff" style={{ color: 'var(--text)', fontSize: '0.9rem' }}>جستجوی کادر</Link>
          {user ? (
            <>
              <Link
                to={user.role === 'facility' ? '/profile/facility' : '/profile/staff'}
                style={{ color: 'var(--text)', fontSize: '0.9rem' }}
              >
                پروفایل من
              </Link>
              <button className="btn btn-outline" onClick={handleLogout} style={{ padding: '0.4rem 1rem' }}>
                خروج
              </button>
            </>
          ) : (
            <Link to="/login"><button className="btn btn-primary" style={{ padding: '0.4rem 1rem' }}>ورود / ثبت‌نام</button></Link>
          )}
        </div>
      </div>
    </nav>
  );
}
