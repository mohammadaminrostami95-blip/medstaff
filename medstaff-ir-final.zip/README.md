# MedStaff (medstaff-ir)
پلتفرم فارسی (RTL) اتصال کادر درمان به مراکز دارای نیاز؛ ثبت‌نام با شماره موبایل و پیامک OTP (کاوه‌نگار).

## اجرای محلی
    cd backend && cp .env.example .env   # مقادیر را ویرایش کنید
    npm install && npm start             # پورت 5000
    cd frontend && npm install && npm run dev   # پورت 5173 (پروکسی /api به 5000)
جداول در حالت development خودکار با Sequelize ساخته می‌شوند (یا `schema.sql`).
در حالت development کد OTP در پاسخ API (`devCode`) برگردانده می‌شود.

## Docker
    JWT_SECRET=... docker compose up --build

## Termux
    pkg install nodejs postgresql git
    mkdir -p $PREFIX/var/lib/postgresql && initdb $PREFIX/var/lib/postgresql
    pg_ctl -D $PREFIX/var/lib/postgresql start
    createdb medstaff
    # در .env: DB_USER=$(whoami) DB_PASS= DB_NAME=medstaff
سپس بک‌اند و فرانت‌اند را مانند اجرای محلی راه بیندازید.
