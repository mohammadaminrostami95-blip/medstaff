CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TYPE enum_staff_type AS ENUM ('physician','nurse','midwife','technician','pharmacist','other');
CREATE TABLE users(id UUID PRIMARY KEY DEFAULT gen_random_uuid(), phone VARCHAR(11) UNIQUE NOT NULL, role VARCHAR(10) NOT NULL DEFAULT 'staff', "isVerified" BOOL DEFAULT false, "isActive" BOOL DEFAULT true, "createdAt" TIMESTAMPTZ DEFAULT now(), "updatedAt" TIMESTAMPTZ DEFAULT now());
CREATE TABLE otp_codes(id UUID PRIMARY KEY DEFAULT gen_random_uuid(), phone VARCHAR(11) NOT NULL, code VARCHAR(6) NOT NULL, "expiresAt" TIMESTAMPTZ NOT NULL, used BOOL DEFAULT false, "createdAt" TIMESTAMPTZ DEFAULT now(), "updatedAt" TIMESTAMPTZ DEFAULT now());
-- Other tables are created by Sequelize sync (NODE_ENV=development); see backend/src/models.
